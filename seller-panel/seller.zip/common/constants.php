
<?php
define('SITE_URL','https://seller.weddingmart.co.in');
define('ASSET_URL',SITE_URL.'/assets/');
define('DIR_SYSTEM', '/home/weddi1pz/public_html/seller-panel/');
define('DIR_IMAGE_SYSTEM','/home/weddi1pz/public_html/weddingmart_images/');
define('SITE_NAME','Wedding Mart');
define('ADMIN_EMAIL','support@weddingmart.com');
define('IMAGE_SITE_URL','https://weddingmart.co.in/weddingmart_images');
define('AUTHKEY','238033Amhqddxg505b9f76c7');
?>