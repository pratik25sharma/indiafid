<div class="popup_box seller_details listing_popup">
	<h4>Upload XLS file</h4>
	<form action="" id="bulk_upload_form" method="post">
		<div class="details_form">
			<div class="row">
				<div class="colums">
					<label for="">
					   Upload file*
					</label>
				   </div>
				<div class="colums">
					<input type="file" name="xls_file" required>
				</div>
			</div>
		</div>
		<div class="row submit_row">
			<a href="javascript:void(0);" class="cancel_popup" title="">Cancel</a>
			<input type="submit" value ="Save" name="submit">
		</div>
	</form>
</div>         
  