	<section class="bn-viewport">
        <div class="wrapper">
            <div class="info">
                <h1>
                    Broadcast your business listings on <span>WeddingMart</span> quickly by signing up in easy steps
                </h1>
                <a href="javascript:void(0);" class="sellWithUs">Sell With Us</a>
            </div>
        </div>
    </section>
    <section class="wm_whysellwithus">
        <div class="wrapper">
            <h4>Why sell with <span>wedding Mart</span></h4>
            <ul>
                <li>
                    <span class="info_image"><img src="<?php echo ASSET_URL ;?>/images/customer.png" alt=""></span>
                    <div class="info">
                        <span>Increase Your Business</span>
                        <p>Increase your business at exponential rate with weddingmart, You will get the daily deals with cusmoter directly.</p>
                    </div>
                </li>
                <li>
                    <span class="info_image"><img src="<?php echo ASSET_URL ;?>/images/lowest-return.png" alt=""></span>
                    <div class="info">
                       <span>Get Daily Reports</span>
                        <p>Check your performance with daily with weddingmart. Choose all of the service on which you are working and keep customer engaged on your profile.</p> 
                    </div>
                </li>
                <li>
                    <span class="info_image">
                        <img src="<?php echo ASSET_URL ;?>/images/securepayment.png" alt="">
                    </span>
                    <div class="info">
                        <span>Earn More Revenue</span>
                        <p>Get more and more customer daily, deal with them directly and increase your business revenue.</p>
                    </div>
                </li>
                <!-- <li>
                    <span class="info_image"><img src="<?php echo ASSET_URL ;?>/images/delivery.png" alt=""></span>
                    <div class="info">
                        <span>Delivery Support</span>
                        <p>Weddingmart takes care of shipping and delivery so you can focus on your core business</p>
                    </div>
                </li>
                <li>
                    <span class="info_image"><img src="<?php echo ASSET_URL ;?>/images/account-manager.png" alt=""></span>
                    <div class="info">
                        <span>Account Manager</span>
                        <p>Weddingmart provides you a dedicated account manager to grow your sales exponentially</p>
                    </div>
                </li> -->
            </ul>
        </div>
    </section>
